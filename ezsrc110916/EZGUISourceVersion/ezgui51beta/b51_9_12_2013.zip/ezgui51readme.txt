EZGUI 5.1 Beta update information:
==================================

Date of this file:   09/12/2013

Bug Fix - Resource leak with form tooltips on page forms

Bug Fix - EZ_Handle failed to return desktop handle for "" parameter

Designer: Added Progressbar when generating code

