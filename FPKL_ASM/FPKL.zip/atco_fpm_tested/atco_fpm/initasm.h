		cld
        xor ecx,ecx
		xor eax,eax
		xor ebx,ebx
		xor edx,edx