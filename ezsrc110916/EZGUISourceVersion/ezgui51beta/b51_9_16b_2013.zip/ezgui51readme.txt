EZGUI 5.1 Beta update information:
==================================

Date of this file:   09/16/2013

Updated Designer with following:

- Cancel added to Save Form dialog
- Apply changed to OK on dialogs
- OK and Cancel button positions changed on dialogs

Date of this file:   09/12/2013

Bug Fix - Resource leak with form tooltips on page forms

Bug Fix - EZ_Handle failed to return desktop handle for "" parameter

Designer: Added Progressbar when generating code



