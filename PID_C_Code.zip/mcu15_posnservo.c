// **********************************************************
// posnservo.c
//
// Created on: 2010-11-17 orginally for xmos 4 core processor
// modified 5/3/2017 for MCU15A, converted to "C"
// **********************************************************

#include "stm32f4xx_hal.h"
#include "math.h"
#include "mcu15_define.h"
#include "mcu15_posnservo.h"
#include "mcu15_smp.h"


    extern    float   period_sec;       // PID filter interval sec

    int8_t enable;            // enable PID filter 1=enable
    int32_t deadband;         // position error where no loop correction occurs
    float pgain;              // loop parameter that compensates for position error
    float igain;              // loop parameter that compensates for long term error
    float dgain;              // loop parameter that compensates for differential error
    float ff1gain;            // loop parameter that compensates for velocity feedfwd
    float ff2gain;            // loop parameter that compensates for acceleration feedfwd

    float drive;              //current drive (-1.0 to 1.0)(not affected by enable)
    int32_t errcnts;          // current posn error in motor encoder counts    

// **********************************************************
// initialize PID filter
// **********************************************************

void InitPID() {

// initialize PID loop default values
// PID tick interval (period_sec) is set in InitMode.c

    PIDsetEnable(0);                        // PID enable = off
    PIDsetDeadband(0);                      // deadband
    PIDsetPgain(1.0);                       // loop position error
    PIDsetIgain(0.0);                       // long term error
    PIDsetDgain(10.0);                      // differential error
    PIDsetFF1gain(0.0);                     // velocity
    PIDsetFF2gain(0.0);                     // acceleration
       
}
                 
// **********************************************************
// Call repeatedly to calc a new motor drive value for selected servo
// typically every 1ms.
// Returns afloat representing the motor drive required.
// ********************************************************** 
float PIDcalc(int32_t actual_posn, int32_t cmd_posn)
{
// vars used by PID calcs
    float error_i;              // cumulative integrator term
    int32_t prev_cmd;
    float prev_cmd_d;
    float prev_error;

    float tmp1;
    float max_i;
    float error_d;              // derivative term
    float cmd_d;                // cycle by cycle delta posncmd = commanded velocity
    float cmd_dd;               // cycle by cycle delta velocity = commanded accel

    // calculate the error
    errcnts = cmd_posn - actual_posn;   // posn err in encoder cnts

    // apply the deadband
    if (errcnts > deadband)
        errcnts -= deadband;
    else if (errcnts < -deadband)
            errcnts += deadband;
    else
        errcnts = 0;

    tmp1 = (float)errcnts;              // position error in fp counts

    // do integrator calcs only if enabled
    if ((igain > 0) && (enable != 0))
    {
        // update integral term
        error_i += tmp1 * period_sec; // scale so it builds slowly (integer igain can be higher)

        // apply a fixed integrator limit of 25% drive(could be made tunable)
        max_i = 25.0f / igain;
        if (error_i > max_i)
            error_i = max_i;
        else if (error_i < -max_i)
            error_i = -max_i;
    }
    else
    {
        // not enabled, reset integrator
        error_i = 0.0f;
    }

    /* calculate derivative term */
    error_d = (tmp1 - prev_error);
    prev_error = tmp1;

    /* calculate derivative of commanded posn = velocity ( used with ff1 tuning param ) */
    cmd_d = (float)(cmd_posn - prev_cmd);
    prev_cmd = cmd_posn;

    /* calculate derivative of velocity = accel (used with ff2 tuning param) */
    cmd_dd = cmd_d - prev_cmd_d;
    prev_cmd_d = cmd_d;

    // calculate the output value by summing drive components
    // because gain components are ints, not fp, 
    // we use some scaling to improve tuning ease
    tmp1 =  (pgain  * tmp1) / 1000.0f;            // position error   component
    tmp1 += (igain  * error_i) / 1000.0f;         // integral error   component
    tmp1 += (dgain  * error_d) / 1000.0f;         // differential     component
    tmp1 += (ff1gain * cmd_d)/ 1000.0f;           // velocity feedfwd component
    tmp1 += (ff2gain * cmd_dd) / 1000.0f;         // accel    feedfwd component

    drive = tmp1;

    // limit drive to max on time of pwm waveform
    if (drive > 1.0f)
        drive = 1.0f;
    else if (drive < -1.0f)
        drive = -1.0f;

    if (enable)
        return(drive);  //  return drive;
    else
        return(0.0f);   // shut off drive for disabled axis
}

// all the get functions for the parameters
float PIDgetPeriod_sec()
{
    return period_sec;   
}

int8_t   PIDgetEnable(void)
{
    return enable;   
}
int32_t   PIDgetDeadband(void)
{
    return deadband;   
}
float PIDgetPgain(void)
{
    return pgain;   
}
float PIDgetIgain(void)
{
    return igain;   
}
float PIDgetDgain(void)
{
    return dgain;   
}
float PIDgetFF1gain(void)
{
    return ff1gain;   
}
float PIDgetFF2gain(void)
{
    return ff2gain;   
}
float PIDgetDrive(void)
{
    return drive;
}

int32_t PIDgetPosnErr(void)
{
    return errcnts;   
}    
// all the parameter set functions
void PIDsetPeriod_sec(float sec)
{
    period_sec = sec;                       
}

void PIDsetEnable(int8_t Enable)
{
    enable = Enable;
} 
   
void PIDsetDeadband(int db)
{
    deadband = db;    
} 
   
void PIDsetPgain(float Pgain)
{
    pgain = Pgain;    
} 
   
void PIDsetIgain(float Igain)
{
    igain = Igain;        
} 
   
void PIDsetDgain(float Dgain)
{
    dgain = Dgain;    
}
    
void PIDsetFF1gain(float Ff1gain)
{
    ff1gain = Ff1gain;
} 
   
void PIDsetFF2gain(float Ff2gain)
{
    ff2gain = Ff2gain;
}    

